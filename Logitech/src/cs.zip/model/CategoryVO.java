package cs.model;

public class CategoryVO {
	
	private String category;
	private String categoryName;
	
	
	public String getCategoryName() {
		return categoryName;
	}

	public void setCategory_name(String category_name) {
		this.categoryName = category_name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
}	

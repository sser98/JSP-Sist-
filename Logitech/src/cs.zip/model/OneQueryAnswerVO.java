package cs.model;

public class OneQueryAnswerVO {
	
	private String seq_oq;
	
	private String oq_content;
	private String answerdate;
	
	
	
	public String getSeq_oq() {
		return seq_oq;
	}
	public void setSeq_oq(String seq_oq) {
		this.seq_oq = seq_oq;
	}
	public String getOq_content() {
		return oq_content;
	}
	public void setOq_content(String oq_content) {
		this.oq_content = oq_content;
	}
	public String getAnswerdate() {
		return answerdate;
	}
	public void setAnswerdate(String answerdate) {
		this.answerdate = answerdate;
	}
	
	
	
}



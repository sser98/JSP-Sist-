package cs.model;

public class Sub_categoryVO {
	
	
	
	private String subCategory;

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}
	
	
	
	
	
	
}
